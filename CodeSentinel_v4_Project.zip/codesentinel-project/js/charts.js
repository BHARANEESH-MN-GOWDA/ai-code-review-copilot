/* RIGHT PANEL */
function renderBarChart(d){
  const s=d.summary;
  const items=[{l:'CRIT',v:s.critical,c:'var(--crit)'},{l:'HIGH',v:s.high,c:'var(--high)'},
    {l:'MED',v:s.medium,c:'var(--med)'},{l:'LOW',v:s.low,c:'var(--low)'},{l:'INFO',v:s.info,c:'var(--info)'}];
  const mx=Math.max(...items.map(i=>i.v),1);
  document.getElementById('barchart').innerHTML=items.map(it=>`
    <div class="bc-wrap">
      <div class="bc-bar" style="height:${Math.max((it.v/mx)*84,4)}px;background:${it.c}" data-v="${it.v}"></div>
      <div class="bc-lbl">${it.l}</div>
    </div>`).join('');
}

function renderRing(d){
  const cats=d.summary.byCategory||{},entries=Object.entries(cats).filter(([,v])=>v>0);
  const total=entries.reduce((a,[,v])=>a+v,0)||1;
  const cols={security:'#ff1744',bug:'#ff6d00',performance:'#ffd600',codesmell:'#00e676',
    architecture:'#448aff',concurrency:'#b388ff',deadcode:'#f48fb1',crypto:'#ff6e40',naming:'#00e5ff'};
  const r=32,cx=42,cy=42,circ=2*Math.PI*r;let off=0;
  const slices=entries.map(([cat,val])=>{
    const dash=(val/total)*circ;
    const sl=`<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${cols[cat]||'#888'}" stroke-width="9"
      stroke-dasharray="${dash} ${circ}" stroke-dashoffset="-${off}" transform="rotate(-90 ${cx} ${cy})"/>`;
    off+=dash;return sl;
  }).join('');
  document.getElementById('ring').innerHTML=`<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#1b2d44" stroke-width="9"/>${slices}`;
  document.getElementById('rleg').innerHTML=entries.map(([cat,val])=>
    `<li><span class="rd" style="background:${cols[cat]||'#888'}"></span>${cat} (${val})</li>`).join('');
}

function renderHotspots(d){  // R-118
  document.getElementById('hotlist').innerHTML=(d.hotspots||[]).map((h,i)=>`
    <div class="hs">
      <div class="hs-n">${i+1}</div>
      <div style="flex:1;min-width:0"><div class="hs-f">${h.file}</div>
        <div class="hs-bm" style="width:${h.riskPct||50}%"></div></div>
      <div class="hs-c">${h.issues}</div>
    </div>`).join('')||'<div style="color:var(--t3);font-size:10px">No hotspot data</div>';
}

function renderCorr(d){  // R-119-123,137-139
  const lvlC={'CRITICAL':'rgba(255,23,68,.12)','HIGH':'rgba(255,109,0,.12)','MEDIUM':'rgba(255,214,0,.08)'};
  document.getElementById('corrlist').innerHTML=(d.correlations||[]).map(c=>`
    <div class="corrcard">
      <div class="corrcard-ttl">${c.id}: ${c.title}</div>
      <div class="corrcard-files">${(c.affectedFiles||[]).slice(0,3).join(' · ')}</div>
      <span class="corrcard-lvl" style="background:${lvlC[c.impactLevel]||'rgba(255,255,255,.04)'}">${c.impactLevel}</span>
      <div class="corrcard-desc">${(c.description||'').slice(0,110)}…</div>
    </div>`).join('')||'<div style="color:var(--t3);font-size:10px">No correlation data</div>';
}

