function renderFileTree(d){
  const fm={};
  d.findings.forEach(f=>{
    if(!fm[f.filePath])fm[f.filePath]={c:0,h:0,m:0,l:0};
    if(f.severity==='CRITICAL')fm[f.filePath].c++;
    else if(f.severity==='HIGH')fm[f.filePath].h++;
    else if(f.severity==='MEDIUM')fm[f.filePath].m++;
    else fm[f.filePath].l++;
  });
  const files=Object.entries(fm).sort((a,b)=>(b[1].c*4+b[1].h*3+b[1].m*2+b[1].l)-(a[1].c*4+a[1].h*3+a[1].m*2+a[1].l));
  document.getElementById('ftree').innerHTML=
    files.map(([fp,cnt])=>{
      const top=cnt.c?'bc':cnt.h?'bh':cnt.m?'bm':'bl';
      const n=cnt.c||cnt.h||cnt.m||cnt.l;
      return `<li class="fi" onclick="filterFile('${fp}')" title="${fp}">
        <span>📄</span><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${fp.split('/').slice(-2).join('/')}</span>
        <span class="fi-badge ${top}">${n}</span></li>`;
    }).join('')+`<li class="fi" onclick="filterFile(null)"><span>🗂</span> All files</li>`;
}

function renderFilterPanel(d){
  const s=d.summary;
  const sevCols={CRITICAL:'var(--crit)',HIGH:'var(--high)',MEDIUM:'var(--med)',LOW:'var(--low)',INFO:'var(--info)'};
  const catIcons={security:'🔒',bug:'🐛',performance:'⚡',codesmell:'🌿',architecture:'🏗',concurrency:'⚙️',deadcode:'🪦',crypto:'🔐',naming:'🏷️'};
  let h=`<div class="fg"><div class="fg-title">By Severity — R-146</div>`;
  ['CRITICAL','HIGH','MEDIUM','LOW','INFO'].forEach(sv=>{
    h+=`<button class="fb" onclick="fSev('${sv}')"><span class="fd" style="background:${sevCols[sv]}"></span>${sv}<span class="fc">${s[sv.toLowerCase()]||0}</span></button>`;
  });
  h+=`</div><div class="fg"><div class="fg-title">By Category — R-148</div>`;
  Object.keys(s.byCategory||{}).forEach(cat=>{
    h+=`<button class="fb" onclick="fCat('${cat}')"><span>${catIcons[cat]||'📌'}</span>${cat}<span class="fc">${s.byCategory[cat]||0}</span></button>`;
  });
  h+=`</div><button class="clr" onclick="clrF()">↩ Clear filters</button>`;
  document.getElementById('fp').innerHTML=h;
}

function renderComponents(d){  // R-149
  document.getElementById('complist').innerHTML=(d.components||[]).map(c=>`
    <div class="citem" onclick="fComp('${c.name}')">
      <div class="cname">${c.name}</div>
      <div class="cmeta"><span>${c.type}</span><span>${c.files?.length||0} files</span><span style="color:var(--high)">${c.issueCount} issues</span><span style="color:var(--t3)">${c.primaryLanguage||''}</span></div>
    </div>`).join('')||'<div style="padding:12px;font-family:var(--font-code);font-size:10px;color:var(--t3)">No component data</div>';
}

function renderArch(d){  // R-150-157
  document.getElementById('archpre').textContent=d.architecture?.diagram||defArch();
}

