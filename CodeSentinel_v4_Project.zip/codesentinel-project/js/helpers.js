/* HELPERS */
function rc(s){return s>=75?'var(--crit)':s>=50?'var(--high)':s>=25?'var(--med)':'var(--low)';}
function rl(s){return s>=75?'🔴 Critical Risk':s>=50?'🟠 High Risk':s>=25?'🟡 Moderate Risk':'🟢 Low Risk';}

/* EXPORTS */
