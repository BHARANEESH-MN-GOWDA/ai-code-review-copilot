const STAGES=[
  {id:'ingest',icon:'📥',lbl:'Repo Ingestion'},     // R-037
  {id:'traverse',icon:'📁',lbl:'Dir Traversal'},    // R-038
  {id:'lang',icon:'🔤',lbl:'Lang Detect'},          // R-039
  {id:'exclude',icon:'🚫',lbl:'Exclude Files'},     // R-041-043
  {id:'ast',icon:'🌳',lbl:'AST Parsing'},           // R-053
  {id:'struct',icon:'🏗',lbl:'Struct Analysis'},    // R-045-052
  {id:'static',icon:'🔎',lbl:'Static Engine'},      // R-013,045
  {id:'ai',icon:'🤖',lbl:'AI LLM Review'},          // R-014
  {id:'security',icon:'🔒',lbl:'Security Scan'},    // R-074-084
  {id:'crypto',icon:'🔐',lbl:'Crypto/TLS'},         // R-078,079
  {id:'cve',icon:'📦',lbl:'CVE Scan'},              // R-080
  {id:'bugs',icon:'🐛',lbl:'Bug Detection'},        // R-066-073
  {id:'perf',icon:'⚡',lbl:'Performance'},           // R-093-099
  {id:'smells',icon:'🌿',lbl:'Code Smells'},        // R-085-092
  {id:'corr',icon:'🔗',lbl:'Correlation'},          // R-055-065
  {id:'score',icon:'📊',lbl:'Scoring'},             // R-106-118
];

/* ── LOADER ─────────────────────────────────────────────────────────── */
function showLdr(){
  document.getElementById('ldr').classList.remove('hid');
  document.getElementById('lsteps').innerHTML=STAGES.map(s=>
    `<div class="ls" id="ls-${s.id}"><span class="li">⬜</span>${s.lbl}</div>`).join('');
}
async function animLdr(){
  for(const s of STAGES){
    const el=document.getElementById(`ls-${s.id}`);if(!el)continue;
    el.classList.add('act');el.querySelector('.li').textContent='🔄';
    document.getElementById('lmsg').textContent=s.lbl+'…';
    await sleep(190+Math.random()*160);
    el.classList.remove('act');el.classList.add('done');el.querySelector('.li').textContent='✅';
  }
}
function hideLdr(){document.getElementById('ldr').classList.add('hid');}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}

