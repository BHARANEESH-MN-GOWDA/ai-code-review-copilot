/* R-129-136 findings */
function renderIssues(findings){
  let show=[...findings];
  if(F.sev)show=show.filter(f=>f.severity===F.sev);
  if(F.cat)show=show.filter(f=>f.category===F.cat);
  if(F.file)show=show.filter(f=>f.filePath===F.file);
  if(F.comp)show=show.filter(f=>f.component===F.comp||f.module===F.comp);
  document.getElementById('fcnt').textContent=`${show.length} issues`;
  document.getElementById('ilist').innerHTML=show.map((f,i)=>`
    <div class="icard" id="ic-${f.id}" style="animation-delay:${i*.025}s">
      <div class="ihdr" onclick="togCard('${f.id}')">
        <span class="stag stag-${f.severity}">${f.severity}</span>
        <span class="ctag">${catIcon(f.category)} ${f.category}</span>
        <span class="iid">${f.id}</span>
        <span class="ititle">${f.title}</span>
        ${f.component?`<span class="icomp">[${f.component}]</span>`:''}
        <span class="iloc">📁 ${f.filePath.split('/').pop()}:${f.lineStart}</span>
        ${f.astNode?`<span class="iast">AST:${f.astNode}</span>`:''}
        <span class="ichev">▾</span>
      </div>
      <div class="ibody">
        <div class="ibgrid">
          <div class="iblk"><label>Description — R-132</label><p>${f.description}</p></div>
          <div class="iblk"><label>Location — R-060-064</label>
            <p class="mono">Repo: ${f.repository||'—'}<br>File: ${f.filePath}<br>Lines: ${f.lineStart}–${f.lineEnd}<br>Fn: ${f.function||'—'}<br>Class: ${f.class||'—'}<br>Module: ${f.module||'—'}<br>Block: ${f.codeBlock||'—'}</p>
          </div>
          <div class="iblk"><label>Explanation — R-073,101</label><p>${f.explanation||f.description}</p></div>
          <div class="iblk"><label>Remediation — R-083,103</label><p>${f.remediationSteps||'—'}</p></div>
          <div class="iblk"><label>Impact of Fix — R-104</label><p>${f.impactOfFix||'—'}</p></div>
          <div class="iblk"><label>Refactoring — R-092,103</label><p>${f.refactoringGuidance||'—'}</p></div>
          <div class="iblk"><label>Standards — R-105</label><p>${f.standardsReference||'—'}</p></div>
          <div class="iblk"><label>Scoring Factors — R-111-115</label>
            ${['securityImpact','runtimeFailure','maintainability','performance','complexity'].map(k=>{
              const v=(f.scoringFactors||{})[k]||0;
              return `<div style="font-family:var(--font-code);font-size:9px;color:var(--t3);margin-bottom:3px">${k}: <span style="color:var(--text)">${v}/10</span></div>`;
            }).join('')}
          </div>
        </div>
        <div class="itags">${(f.impactTags||[]).map(t=>`<span class="itag">⚑ ${t}</span>`).join('')}</div>
        ${f.correlatedIssues?.length?`<span class="corrlink">Linked — R-137: ${f.correlatedIssues.join(', ')}</span>`:''}
        ${f.affectedCode?`<div class="code-block" style="margin-top:10px">
          <div class="cb-hdr"><span class="cb-lbl cbl-bad">⚠ Affected Code — R-100</span>
          <span style="font-family:var(--font-code);font-size:9px;color:var(--t3)">${f.filePath}:${f.lineStart}</span></div>
          <pre class="cb-pre">${codeLines(f.affectedCode,f.lineStart,true)}</pre></div>`:''}
        ${f.suggestedFix?`<div class="code-block" style="margin-top:8px">
          <div class="cb-hdr"><span class="cb-lbl cbl-good">✓ Suggested Fix — R-102</span></div>
          <pre class="cb-pre">${codeLines(f.suggestedFix,f.lineStart,false)}</pre></div>`:''}
      </div>
    </div>`).join('')||`<div style="text-align:center;color:var(--t3);padding:36px;font-family:var(--font-code)">No issues match filters</div>`;
}

function codeLines(code,start,isIssue){
  return (code||'').split('\n').map((l,i)=>
    `<span class="${isIssue&&i===0?'hl':!isIssue&&i===0?'ok':''}"><span class="lnum">${start+i}</span>${esc(l)}</span>`
  ).join('\n');
}
function esc(s){return(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function catIcon(c){return{security:'🔒',bug:'🐛',performance:'⚡',codesmell:'🌿',architecture:'🏗',concurrency:'⚙️',deadcode:'🪦',crypto:'🔐',naming:'🏷️'}[c]||'📌';}

