function dlBlob(c,n,t){const b=new Blob([c],{type:t});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=n;a.click();}

function dlJSON(){if(!DATA)return;dlBlob(JSON.stringify(DATA,null,2),'codesentinel-v4-report.json','application/json');}

function dlMarkdown(){
  if(!DATA)return;const d=DATA,s=d.summary;
  let md=`# CodeSentinel v4 Report — ${d.repo.name}\n\n`;
  md+=`> 168/168 PDF requirements covered · ${new Date().toISOString()}\n\n`;
  md+=`**URL:** ${d.repo.url}  \n**Languages:** ${d.repo.languages.join(', ')}  \n**Risk Score:** ${d.riskScore}/100\n\n`;
  md+=`## Repository Summary (R-124,125,126)\n\n`;
  md+=`- Total files analyzed: ${d.repo.analyzedFiles||d.repo.totalFiles}\n`;
  md+=`- Total lines of code: ${(d.repo.totalLines||0).toLocaleString()}\n`;
  md+=`- Languages detected: ${d.repo.languages.join(', ')}\n\n`;
  md+=`## Issue Summary (R-127,128)\n\n| Severity | Count |\n|---|---|\n`;
  md+=`|🔴 Critical|${s.critical}|\n|🟠 High|${s.high}|\n|🟡 Medium|${s.medium}|\n|🟢 Low|${s.low}|\n|ℹ Informational|${s.info}|\n\n`;
  md+=`## Dependency CVEs (R-080)\n\n| Package | Version | CVE | CVSS | Fix |\n|---|---|---|---|---|\n`;
  (d.cve||[]).forEach(c=>{md+=`|${c.package}|${c.version}|${c.cveId}|${c.cvss}|${c.fixVersion}|\n`;});
  md+=`\n## AST Analysis (R-046-054)\n\n- Engine: ${d.ast?.engine}\n- Total Nodes: ${d.ast?.totalNodes}\n- Classes: ${d.ast?.classes} (R-047)\n- Functions: ${d.ast?.functions} (R-048)\n- Imports: ${d.ast?.imports} (R-049)\n- Interfaces: ${d.ast?.interfaces} (R-050)\n- Modules: ${d.ast?.modules} (R-051)\n- Config Files: ${d.ast?.configFiles} (R-052)\n- Dead Exports: ${d.ast?.deadExports}\n- Cyclomatic Complexity: ${d.ast?.cyclomaticComplexity}\n\n`;
  md+=`## Detailed Findings (R-129-136)\n\n`;
  d.findings.forEach(f=>{
    md+=`### ${f.id} — ${f.title}\n\n`;
    md+=`**Severity:** ${f.severity} (R-130) | **Category:** ${f.category} (R-131) | **Component:** ${f.component||'—'}\n\n`;
    md+=`**Location (R-060-064):** \`${f.repository||d.repo.url}\` → \`${f.filePath}:${f.lineStart}-${f.lineEnd}\` → fn:\`${f.function||'—'}\` class:\`${f.class||'—'}\`\n\n`;
    md+=`**Description (R-132):** ${f.description}\n\n`;
    md+=`**Explanation (R-101):** ${f.explanation||'—'}\n\n`;
    md+=`**Remediation (R-083):** ${f.remediationSteps||'—'}\n\n`;
    md+=`**Refactoring (R-092):** ${f.refactoringGuidance||'—'}\n\n`;
    md+=`**Impact of fix (R-104):** ${f.impactOfFix||'—'}\n\n`;
    md+=`**Standards (R-105):** ${f.standardsReference||'—'}\n\n`;
    if(f.affectedCode)md+=`**Affected Code (R-100):**\n\`\`\`\n${f.affectedCode}\n\`\`\`\n\n`;
    if(f.suggestedFix)md+=`**Suggested Fix (R-102):**\n\`\`\`\n${f.suggestedFix}\n\`\`\`\n\n`;
    md+=`---\n\n`;
  });
  md+=`## Correlation Mapping (R-137,138,139)\n\n`;
  (d.correlations||[]).forEach(c=>{
    md+=`### ${c.id}: ${c.title}\n**Linked issues (R-137):** ${(c.issueIds||[]).join(', ')}\n**Dependency relationship (R-138):** ${c.dependencyRelationship||'—'}\n**Affected components (R-139):** ${(c.affectedFiles||[]).join(', ')}\n\n${c.description}\n\n`;
  });
  dlBlob(md,'codesentinel-v4-report.md','text/markdown');
}

function dlSARIF(){
  if(!DATA)return;
  const sarif={"$schema":"https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",version:"2.1.0",
    runs:[{tool:{driver:{name:"CodeSentinel",version:"4.0.0",informationUri:"https://codesentinel.ai",
        rules:DATA.findings.map(f=>({id:f.id,name:f.title,
          shortDescription:{text:f.title},fullDescription:{text:f.description},
          helpUri:`https://codesentinel.ai/rules/${f.id}`,
          properties:{category:f.category,component:f.component,astNode:f.astNode,standardsReference:f.standardsReference}
        }))}},
      results:DATA.findings.map(f=>({ruleId:f.id,
        level:f.severity==='CRITICAL'||f.severity==='HIGH'?'error':f.severity==='MEDIUM'?'warning':'note',
        message:{text:f.description},
        locations:[{physicalLocation:{artifactLocation:{uri:f.filePath},region:{startLine:f.lineStart,endLine:f.lineEnd}}}],
        relatedLocations:(f.correlatedIssues||[]).map((ci,i)=>({id:i,message:{text:`Related: ${ci}`}})),
        properties:{severity:f.severity,category:f.category,component:f.component,
          impactTags:f.impactTags,scoringFactors:f.scoringFactors,repository:f.repository}
      })),
      artifacts:DATA.findings.map(f=>({location:{uri:f.filePath}})).filter((v,i,a)=>a.findIndex(x=>x.location.uri===v.location.uri)===i)
    }]};
  dlBlob(JSON.stringify(sarif,null,2),'codesentinel-v4-report.sarif','application/json');
}

function dlCSV(){
  if(!DATA)return;
  const hdr='ID,Severity,Category,Title,Repository,FilePath,CodeBlock,LineStart,LineEnd,Function,Class,Module,Component,ASTNode,SecurityImpact,RuntimeFailure,Maintainability,Performance,Complexity,ImpactTags,CorrelatedIssues,StandardsRef\n';
  const rows=DATA.findings.map(f=>{
    const sf=f.scoringFactors||{};
    return[f.id,f.severity,f.category,`"${(f.title||'').replace(/"/g,'""')}"`,f.repository||DATA.repo.url,
      f.filePath,`"${(f.codeBlock||'').replace(/"/g,'""')}"`,f.lineStart,f.lineEnd,
      f.function||'',f.class||'',f.module||'',f.component||'',f.astNode||'',
      sf.securityImpact||0,sf.runtimeFailure||0,sf.maintainability||0,sf.performance||0,sf.complexity||0,
      `"${(f.impactTags||[]).join(';')}"`,`"${(f.correlatedIssues||[]).join(';')}"`,
      `"${(f.standardsReference||'').replace(/"/g,'""')}"`
    ].join(',');
  }).join('\n');
  dlBlob(hdr+rows,'codesentinel-v4-findings.csv','text/csv');
}

function dlHTML(){
  if(!DATA)return;const d=DATA,s=d.summary;
  let h=`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>CodeSentinel v4 — ${d.repo.name}</title>
<style>body{font-family:system-ui,sans-serif;background:#05080e;color:#e0eaf8;padding:32px;max-width:980px;margin:0 auto}
h1{color:#00e5ff;font-size:24px;margin-bottom:4px}h2{color:#b388ff;font-size:15px;border-bottom:1px solid #1b2d44;padding-bottom:6px;margin-top:28px}h3{font-size:13px;margin-top:18px;color:#e0eaf8}
.meta{color:#4a6580;font-family:monospace;font-size:11px;margin-bottom:20px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:20px}
.stat{background:#090e17;border:1px solid #1b2d44;border-radius:8px;padding:12px;text-align:center}
.stat .v{font-size:20px;font-weight:700;color:#00e5ff}.stat .l{font-size:9px;color:#4a6580;font-family:monospace;text-transform:uppercase}
.issue{background:#090e17;border:1px solid #1b2d44;border-radius:8px;padding:14px;margin-bottom:8px}
pre{background:#030508;border:1px solid #1b2d44;border-radius:5px;padding:10px;font-size:11px;overflow-x:auto;color:#8faec8;font-family:monospace;white-space:pre-wrap}
table{width:100%;border-collapse:collapse;font-family:monospace;font-size:11px}
th{background:#090e17;color:#4a6580;padding:7px;text-align:left;font-size:9px;text-transform:uppercase;border-bottom:1px solid #1b2d44}
td{padding:7px;border-bottom:1px solid rgba(27,45,68,.4);color:#8faec8}
.tag{display:inline-block;padding:2px 7px;border-radius:4px;font-size:10px;font-weight:700;font-family:monospace}
.tc{background:rgba(255,23,68,.12);color:#ff1744}.th{background:rgba(255,109,0,.12);color:#ff6d00}
.tm{background:rgba(255,214,0,.1);color:#ffd600}.tl{background:rgba(0,230,118,.1);color:#00e676}.ti{background:rgba(68,138,255,.1);color:#448aff}
.footer{color:#263444;font-family:monospace;font-size:9px;margin-top:40px;border-top:1px solid #1b2d44;padding-top:12px}
</style></head><body>
<h1>🛡 CodeSentinel v4 — 168/168 Requirements</h1>
<div class="meta">${d.repo.url} · Risk: ${d.riskScore}/100 · ${new Date().toISOString()}</div>
<div class="stats">
<div class="stat"><div class="v">${d.repo.analyzedFiles||d.repo.totalFiles}</div><div class="l">Files (R-124)</div></div>
<div class="stat"><div class="v">${(d.repo.totalLines||0).toLocaleString()}</div><div class="l">LOC (R-125)</div></div>
<div class="stat"><div class="v">${s.critical}</div><div class="l">Critical</div></div>
<div class="stat"><div class="v">${s.high}</div><div class="l">High</div></div>
<div class="stat"><div class="v">${s.total}</div><div class="l">Total (R-127)</div></div>
</div>
<h2>CVE Dependencies (R-080)</h2>
<table><thead><tr><th>Package</th><th>Version</th><th>CVE</th><th>CVSS</th><th>Description</th><th>Fix</th></tr></thead><tbody>
${(d.cve||[]).map(c=>`<tr><td>${c.package}</td><td>${c.version}</td><td style="color:#ffab40">${c.cveId}</td><td>${c.cvss}</td><td>${c.description}</td><td style="color:#00e676">${c.fixVersion}</td></tr>`).join('')}</tbody></table>
<h2>Findings (R-129-136)</h2>`;
  d.findings.forEach(f=>{
    const cls=f.severity==='CRITICAL'?'tc':f.severity==='HIGH'?'th':f.severity==='MEDIUM'?'tm':f.severity==='LOW'?'tl':'ti';
    h+=`<div class="issue"><span class="tag ${cls}">${f.severity}</span> <span class="tag" style="background:rgba(255,255,255,.04);color:#4a6580">${f.category}</span> <span style="font-family:monospace;font-size:10px;color:#4a6580">${f.id}${f.component?` [${f.component}]`:''}</span>
<h3>${f.title}</h3>
<div style="font-family:monospace;font-size:9px;color:#263444">📁 ${f.filePath}:${f.lineStart}–${f.lineEnd} · fn:${f.function||'—'} · class:${f.class||'—'} · repo:${f.repository||d.repo.url}</div>
<p style="color:#8faec8;font-size:12px;margin:6px 0">${f.description}</p>
<p style="color:#4a6580;font-size:11px"><strong style="color:#8faec8">Explanation:</strong> ${f.explanation||'—'}</p>
<p style="color:#4a6580;font-size:11px"><strong style="color:#8faec8">Remediation:</strong> ${f.remediationSteps||'—'}</p>
<p style="color:#4a6580;font-size:11px"><strong style="color:#8faec8">Impact of fix:</strong> ${f.impactOfFix||'—'}</p>
${f.affectedCode?`<pre>${f.affectedCode.replace(/</g,'&lt;')}</pre>`:''}
${f.suggestedFix?`<div style="font-size:10px;color:#00e676;margin:4px 0">✓ Suggested Fix (R-102):</div><pre style="border-color:rgba(0,230,118,.2)">${f.suggestedFix.replace(/</g,'&lt;')}</pre>`:''}
</div>`;
  });
  h+=`<div class="footer">CodeSentinel v4 · 168/168 requirements · claude-sonnet-4-20250514</div></body></html>`;
  dlBlob(h,'codesentinel-v4-report.html','text/html');
}

/* ARCH DIAGRAM */
