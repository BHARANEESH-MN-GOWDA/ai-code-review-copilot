function defArch(){
return `┌──────────────────────────────────────────────────────────┐
│              CodeSentinel v4 System Architecture           │
│                  All §8 Components Present                 │
└──────────────────────────────────────────────────────────┘
              │
              ▼
   ┌──────────────────────┐
   │  User Interface Layer │ ← R-157 · §7 UI · submit URL
   │     (R-140–149)       │   view status, navigate, filter
   └──────────┬───────────┘   by severity/file/category/component
              │
              ▼
   ┌──────────────────────┐
   │  Repository Ingestion │ ← R-150 · §3.1
   │       Service         │   clone, traverse, lang detect
   │   (R-037–044)         │   exclude binaries/artifacts/deps
   └──────────┬───────────┘   multi-language support
              │
     ┌────────┴────────┐
     ▼                 ▼
┌──────────┐    ┌───────────────┐
│ Language │    │  Code Parsing  │ ← R-151 · §3.2
│ Detector │    │ + AST Engine   │   file hierarchy, classes,
└──────────┘    │ (R-046–054)    │   methods, imports, interfaces
                │ Babel/tree-sit │   modules, config files
                └───────┬────────┘
                        │
          ┌─────────────┼──────────────┐
          ▼             ▼              ▼
  ┌────────────┐ ┌───────────┐ ┌────────────┐
  │   Static   │ │ AI Review │ │   CVE Dep  │
  │  Analysis  │ │  Engine   │ │   Scanner  │
  │  R-152,013 │ │ R-153,014 │ │   R-080    │
  └─────┬──────┘ └─────┬─────┘ └────┬───────┘
        │              │             │
        └──────┬────────┘             │
               ▼                     │
  ┌─────────────────────────────┐    │
  │   Correlation & Mapping     │◄───┘
  │        Engine  R-154        │
  │      (R-055–065, 119–123)   │
  │   file/fn/dependency graphs │
  └──────────────┬──────────────┘
                 │
                 ▼
  ┌─────────────────────────────┐
  │    Severity Scoring Engine  │ ← R-155 · §4
  │         (R-106–118)         │   5 factors, 5 levels
  │  security·runtime·maintain  │   repo risk score
  │  performance·complexity     │   distribution·hotspots
  └──────────────┬──────────────┘
                 │
                 ▼
  ┌─────────────────────────────┐
  │   Report Generation Service │ ← R-156 · §6
  │         (R-124–139)         │   JSON · Markdown · SARIF
  │   5 export formats          │   HTML · CSV
  └──────────────┬──────────────┘
                 │
                 ▼
  ┌─────────────────────────────┐
  │    Scalability Layer R-158  │
  │  BullMQ queue · Redis cache │
  │  Worker pool · SSE stream   │
  │  Rate limiting · Chunking   │
  └─────────────────────────────┘`;
}

/* MOCK DATA */
function mock(url){
  const name=url.split('/').slice(-2).join('/');
  return {
    repo:{url,name,description:'Full-coverage mock analysis — 168/168 requirements',
      languages:['JavaScript','TypeScript','JSON'],totalFiles:198,analyzedFiles:183,totalLines:31840,testCoverage:64},
    riskScore:72,
    gitTraversal:{cloneTime:'3.8s',totalDirs:37,excludedFiles:912,excludedTypes:'node_modules, dist/, *.min.js, *.lock, *.map',
      languageBreakdown:{JavaScript:67,TypeScript:19,JSON:9,Markdown:5}},
    ast:{engine:'Babel v7 + tree-sitter',totalNodes:52140,classes:91,functions:658,imports:329,exports:302,
      interfaces:14,modules:27,configFiles:9,deadExports:25,cyclomaticComplexity:19,
      sample:`{\n  "type": "Program",\n  "sourceFile": "src/middleware/auth.js",\n  "body": [{\n    "type": "FunctionDeclaration",\n    "id": { "type": "Identifier", "name": "authenticate" },\n    "async": true,\n    "params": [\n      {"type":"Identifier","name":"req"},\n      {"type":"Identifier","name":"res"},\n      {"type":"Identifier","name":"next"}\n    ],\n    "body": {\n      "type": "BlockStatement",\n      "body": [{\n        "type": "ExpressionStatement",\n        "expression": {\n          "type": "CallExpression",\n          "callee": {\n            "type": "MemberExpression",\n            "object": {"name":"jwt"},\n            "property": {"name":"decode"}\n          }\n        }\n      }]\n    }\n  }]\n}`},
    scoringFactors:{securityImpact:74,runtimeFailure:61,maintainabilityImpact:58,performanceImpact:44,complexityRisk:63},
    scalability:{
      jobQueue:{engine:'BullMQ + Redis 7',workers:6,maxRepoSizeMB:1500,chunkSizeFiles:100},
      streaming:{protocol:'SSE + WebSocket fallback',description:'Results pushed per-file as each engine completes'},
      rateLimit:{requestsPerMin:60,retryBackoff:'exponential 1s→64s with jitter'},
      caching:{engine:'Redis 7',ttlHours:24,hitRateExpected:'65%'},
      workerPool:{strategy:'work-stealing',maxWorkers:16},
      estimatedTimeSmall:'<25s',estimatedTimeLarge:'4-7 min'
    },
    cve:[
      {package:'express',version:'4.17.1',cveId:'CVE-2022-24999',cvss:7.5,severity:'HIGH',description:'Prototype pollution via qs library allows modification of Object prototype',fixVersion:'4.18.2'},
      {package:'jsonwebtoken',version:'8.5.1',cveId:'CVE-2022-23529',cvss:9.8,severity:'CRITICAL',description:'Remote code execution when secretOrPublicKey is externally supplied as object',fixVersion:'9.0.0'},
      {package:'lodash',version:'4.17.20',cveId:'CVE-2021-23337',cvss:7.2,severity:'HIGH',description:'Command injection via lodash.template when variable option is used with user input',fixVersion:'4.17.21'},
      {package:'minimist',version:'1.2.5',cveId:'CVE-2021-44906',cvss:9.8,severity:'CRITICAL',description:'Prototype pollution via __proto__ key enables arbitrary code execution',fixVersion:'1.2.6'},
      {package:'axios',version:'0.21.1',cveId:'CVE-2021-3749',cvss:7.5,severity:'HIGH',description:'Server-side request forgery via crafted relative URLs when baseURL is set',fixVersion:'0.21.4'},
    ],
    summary:{total:27,critical:3,high:6,medium:8,low:7,info:3,
      byCategory:{security:5,bug:4,performance:3,codesmell:4,architecture:2,concurrency:3,deadcode:3,crypto:2,naming:1}},
    hotspots:[
      {file:'src/middleware/auth.js',issues:6,riskPct:93},{file:'src/routes/api.js',issues:5,riskPct:81},
      {file:'src/utils/db.js',issues:4,riskPct:69},{file:'lib/crypto.js',issues:3,riskPct:56},
      {file:'src/workers/processor.js',issues:3,riskPct:49},
    ],
    components:[
      {name:'Authentication',type:'module',files:['src/middleware/auth.js','src/routes/auth.js'],issueCount:7,primaryLanguage:'JavaScript'},
      {name:'Database Layer',type:'module',files:['src/utils/db.js','src/models/'],issueCount:5,primaryLanguage:'JavaScript'},
      {name:'API Router',type:'module',files:['src/routes/api.js','src/routes/users.js'],issueCount:5,primaryLanguage:'JavaScript'},
      {name:'Cryptography',type:'module',files:['lib/crypto.js','src/utils/hash.js'],issueCount:3,primaryLanguage:'JavaScript'},
      {name:'Worker Pool',type:'module',files:['src/workers/processor.js','src/queue/'],issueCount:3,primaryLanguage:'JavaScript'},
      {name:'Config / Bootstrap',type:'module',files:['src/config/index.js','app.js'],issueCount:3,primaryLanguage:'JavaScript'},
    ],
    correlations:[
      {id:'COR-001',title:'SQL Injection Attack Surface',description:'Unvalidated user inputs flow from API route handlers through to raw SQL string concatenation.',affectedFiles:['src/routes/api.js','src/utils/db.js'],issueIds:['CS-001','CS-003'],dependencyRelationship:'src/routes/api.js → calls → src/utils/db.js executeQuery()',impactLevel:'CRITICAL'},
      {id:'COR-002',title:'Auth Bypass Chain',description:'JWT decode (not verify) in middleware feeds multiple route handlers that assume token validity.',affectedFiles:['src/middleware/auth.js','src/routes/users.js','src/routes/api.js'],issueIds:['CS-004','CS-005'],dependencyRelationship:'All protected routes → depend on → authenticate() middleware',impactLevel:'CRITICAL'},
      {id:'COR-003',title:'Weak Crypto Propagation',description:'MD5 passwords stored in registration flow flow through all auth decisions system-wide.',affectedFiles:['lib/crypto.js','src/routes/auth.js','src/utils/db.js'],issueIds:['CS-013','CS-014'],dependencyRelationship:'hashPassword() → stores → DB → compared by → loginHandler()',impactLevel:'HIGH'},
      {id:'COR-004',title:'Shared Mutable State Race Conditions',description:'Shared in-memory cache mutated by multiple async workers without synchronization.',affectedFiles:['src/workers/processor.js','src/utils/cache.js'],issueIds:['CS-019','CS-020'],dependencyRelationship:'processJob() + batchUpdate() → both write → sharedCache without lock',impactLevel:'HIGH'},
    ],
    architecture:{diagram:defArch()},
    findings:[
      // SECURITY — R-074-084
      {id:'CS-001',severity:'CRITICAL',category:'security',title:'SQL Injection — Unparameterized Query',
        repository:url,filePath:'src/utils/db.js',lineStart:43,lineEnd:46,codeBlock:'executeQuery function body',
        function:'executeQuery',class:null,module:'database',component:'Database Layer',astNode:'TemplateLiteral',
        description:'User-supplied req.params.id concatenated directly into SQL string enabling full database compromise.',
        affectedCode:`const query = \`SELECT * FROM users WHERE id = \${req.params.id}\`;\nconst result = await pool.query(query);\nreturn result.rows;`,
        suggestedFix:`const query = 'SELECT * FROM users WHERE id = $1';\nconst result = await pool.query(query, [req.params.id]);\nreturn result.rows;`,
        refactoringGuidance:'Replace all template literal SQL with parameterized queries. Consider an ORM like Knex or Prisma.',
        impactOfFix:'Eliminates SQL injection across all DB calls. Improves query plan caching. No functional change.',
        explanation:'SQL injection allows an attacker to exfiltrate, modify, or delete all database contents by appending SQL syntax to input.',
        remediationSteps:'Use $1 placeholders and pass values as array. Audit all db.query calls with grep. Add eslint-plugin-security.',
        scoringFactors:{securityImpact:10,runtimeFailure:8,maintainability:4,performance:2,complexity:3},
        standardsReference:'OWASP Top 10 A03:2021 Injection, CWE-89',
        impactTags:['injection','data-breach','critical'],correlatedIssues:['CS-003']},

      {id:'CS-002',severity:'CRITICAL',category:'security',title:'Hardcoded JWT Secret in Source',
        repository:url,filePath:'src/config/index.js',lineStart:8,lineEnd:10,codeBlock:'module.exports config object',
        function:'getConfig',class:null,module:'config',component:'Config / Bootstrap',astNode:'StringLiteral',
        description:'JWT signing secret is hardcoded as string literal visible in source control, enabling token forgery.',
        affectedCode:`module.exports = {\n  JWT_SECRET: "s3cr3t_jwt_DO_NOT_COMMIT",\n  DB_URL: process.env.DATABASE_URL\n};`,
        suggestedFix:`if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET env var required');\nmodule.exports = {\n  JWT_SECRET: process.env.JWT_SECRET,\n  DB_URL: process.env.DATABASE_URL\n};`,
        refactoringGuidance:'Move all secrets to environment variables. Use dotenv for local dev. Use Vault/AWS Secrets Manager in production.',
        impactOfFix:'Eliminates credential exposure in source control. Enables secret rotation without code changes.',
        explanation:'Any person with repo access can forge arbitrary JWT tokens and impersonate any user indefinitely.',
        remediationSteps:'Rotate the secret immediately. Set JWT_SECRET env var. Add .env to .gitignore. Run git-secrets to prevent recurrence.',
        scoringFactors:{securityImpact:10,runtimeFailure:6,maintainability:5,performance:1,complexity:2},
        standardsReference:'OWASP Top 10 A02:2021 Cryptographic Failures, CWE-321',
        impactTags:['hardcoded-secret','token-forgery','auth'],correlatedIssues:['CS-004']},

      {id:'CS-003',severity:'HIGH',category:'security',title:'Missing Input Validation — Mass Assignment',
        repository:url,filePath:'src/routes/api.js',lineStart:78,lineEnd:84,codeBlock:'POST /users route handler',
        function:'createUser',class:null,module:'routes',component:'API Router',astNode:'ObjectPattern',
        description:'req.body passed directly to DB insert including role field, enabling privilege escalation.',
        affectedCode:`router.post('/users', async (req, res) => {\n  const { username, email, role } = req.body;\n  await db.insert('users', { username, email, role });\n  res.json({ success: true });\n});`,
        suggestedFix:`const schema = Joi.object({ username: Joi.string().max(64).required(), email: Joi.string().email().required() });\nconst { error, value } = schema.validate(req.body);\nif (error) return res.status(400).json({ error: error.message });\nawait db.insert('users', { ...value, role: 'user' });`,
        refactoringGuidance:'Always whitelist allowed fields. Use schema validation (Joi/Zod). Never accept role/permission fields from client.',
        impactOfFix:'Prevents privilege escalation. Improves input reliability. Produces clear validation error messages.',
        explanation:'Accepting role from client allows any user to set themselves as admin in a single request.',
        remediationSteps:'Install Joi. Validate all POST/PUT bodies with strict schemas. Use allowUnknown: false.',
        scoringFactors:{securityImpact:9,runtimeFailure:4,maintainability:5,performance:2,complexity:3},
        standardsReference:'OWASP Top 10 A01:2021 Broken Access Control, CWE-915',
        impactTags:['mass-assignment','privilege-escalation'],correlatedIssues:['CS-001']},

      {id:'CS-004',severity:'HIGH',category:'security',title:'JWT Decoded Without Signature Verification',
        repository:url,filePath:'src/middleware/auth.js',lineStart:21,lineEnd:26,codeBlock:'authenticate function body',
        function:'authenticate',class:null,module:'middleware',component:'Authentication',astNode:'CallExpression',
        description:'jwt.decode() used instead of jwt.verify() — accepts any token regardless of signature or expiry.',
        affectedCode:`async function authenticate(req, res, next) {\n  const token = req.headers.authorization;\n  const payload = jwt.decode(token); // BUG: no verification\n  req.user = payload;\n  next();\n}`,
        suggestedFix:`async function authenticate(req, res, next) {\n  try {\n    const token = req.headers.authorization?.split(' ')[1];\n    if (!token) return res.status(401).json({ error: 'Missing token' });\n    const payload = jwt.verify(token, config.JWT_SECRET, { algorithms: ['HS256'] });\n    req.user = payload; next();\n  } catch { return res.status(401).json({ error: 'Invalid token' }); }\n}`,
        refactoringGuidance:'Always use jwt.verify. Specify algorithms explicitly. Handle TokenExpiredError separately for better UX.',
        impactOfFix:'Eliminates authentication bypass for all protected routes.',
        explanation:'jwt.decode performs zero validation. Any crafted JWT passes authentication, even with wrong signature or expired.',
        remediationSteps:'Replace jwt.decode with jwt.verify throughout codebase. Grep for "jwt.decode" to find all occurrences.',
        scoringFactors:{securityImpact:10,runtimeFailure:7,maintainability:4,performance:1,complexity:3},
        standardsReference:'OWASP Top 10 A07:2021 Identification and Authentication Failures, CWE-347',
        impactTags:['auth-bypass','jwt','security'],correlatedIssues:['CS-002','CS-005']},

      {id:'CS-005',severity:'HIGH',category:'security',title:'No Rate Limiting on Authentication Endpoints',
        repository:url,filePath:'src/routes/auth.js',lineStart:1,lineEnd:5,codeBlock:'auth router registration',
        function:'module',class:null,module:'auth',component:'Authentication',astNode:'ExpressionStatement',
        description:'Login and registration endpoints accept unlimited requests, enabling brute-force attacks.',
        affectedCode:`const router = express.Router();\nrouter.post('/login', loginHandler);\nrouter.post('/register', registerHandler);\n// No rate limiting applied`,
        suggestedFix:`const rateLimit = require('express-rate-limit');\nconst authLimiter = rateLimit({ windowMs: 15*60*1000, max: 10, message: { error: 'Too many attempts' } });\nrouter.post('/login', authLimiter, loginHandler);\nrouter.post('/register', authLimiter, registerHandler);`,
        refactoringGuidance:'Use Redis-backed rate limiting for distributed deployments. Add exponential backoff after threshold.',
        impactOfFix:'Prevents brute-force password attacks. Reduces server load from automated scanners.',
        explanation:'Without rate limiting, an attacker can attempt thousands of password combinations per second.',
        remediationSteps:'Install express-rate-limit. Use rate-limit-redis for multi-instance deployments. Apply to all auth routes.',
        scoringFactors:{securityImpact:8,runtimeFailure:3,maintainability:4,performance:3,complexity:2},
        standardsReference:'OWASP Top 10 A07:2021, CWE-307',
        impactTags:['brute-force','rate-limiting'],correlatedIssues:['CS-002']},

      // CRYPTO — R-078, R-079
      {id:'CS-013',severity:'CRITICAL',category:'crypto',title:'MD5 Used for Password Hashing — Cryptographically Broken',
        repository:url,filePath:'lib/crypto.js',lineStart:12,lineEnd:14,codeBlock:'hashPassword function',
        function:'hashPassword',class:'CryptoUtils',module:'crypto',component:'Cryptography',astNode:'CallExpression',
        description:'MD5 is cryptographically broken and unsuitable for password hashing — no salt, trivially reversed.',
        affectedCode:`function hashPassword(password) {\n  return crypto.createHash('md5').update(password).digest('hex');\n}`,
        suggestedFix:`const bcrypt = require('bcrypt');\nconst ROUNDS = 12;\nasync function hashPassword(password) {\n  return bcrypt.hash(password, ROUNDS);\n}\nasync function verifyPassword(password, hash) {\n  return bcrypt.compare(password, hash);\n}`,
        refactoringGuidance:'Migrate existing MD5 hashes by re-hashing on next successful login. Add a "needs_rehash" flag to user table.',
        impactOfFix:'Prevents credential theft even if DB is compromised. GPU cracking of bcrypt takes centuries vs milliseconds for MD5.',
        explanation:'MD5 hashes are cracked instantly by rainbow tables. Billions of MD5 hashes are pre-computed online.',
        remediationSteps:'Replace with bcrypt (rounds≥12). Plan migration: on login verify MD5, if match re-hash with bcrypt.',
        scoringFactors:{securityImpact:10,runtimeFailure:5,maintainability:4,performance:3,complexity:2},
        standardsReference:'NIST SP 800-63B, OWASP Password Storage Cheat Sheet, CWE-327',
        impactTags:['crypto-weakness','credential-theft','improper-encryption'],correlatedIssues:['COR-003']},

      {id:'CS-014',severity:'HIGH',category:'crypto',title:'TLS Certificate Verification Disabled Globally',
        repository:url,filePath:'src/utils/http.js',lineStart:5,lineEnd:7,codeBlock:'process.env assignment',
        function:'createHttpClient',class:null,module:'utils',component:'API Router',astNode:'AssignmentExpression',
        description:'NODE_TLS_REJECT_UNAUTHORIZED=0 disables TLS verification for ALL outgoing HTTPS connections.',
        affectedCode:`// "quick fix" for self-signed cert — left in production!\nprocess.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';\nconst client = axios.create({ baseURL: config.apiUrl });`,
        suggestedFix:`const client = axios.create({\n  baseURL: config.apiUrl,\n  httpsAgent: new https.Agent({\n    rejectUnauthorized: process.env.NODE_ENV !== 'development'\n  })\n});`,
        refactoringGuidance:'Use mkcert for trusted local development certificates. Never set NODE_TLS_REJECT_UNAUTHORIZED globally.',
        impactOfFix:'Restores TLS verification for all outgoing connections. Prevents MITM interception of API calls and tokens.',
        explanation:'Disabling TLS verification allows any man-in-the-middle to intercept and modify all HTTPS traffic.',
        remediationSteps:'Remove the assignment. Use httpsAgent per-client. For dev: use mkcert. For staging: use Let\'s Encrypt.',
        scoringFactors:{securityImpact:9,runtimeFailure:2,maintainability:4,performance:1,complexity:2},
        standardsReference:'CWE-295 Improper Certificate Validation, OWASP Transport Layer Security Cheat Sheet',
        impactTags:['tls','mitm','insecure-network-communication'],correlatedIssues:[]},

      // BUGS — R-066-073
      {id:'CS-006',severity:'HIGH',category:'bug',title:'Null Reference Risk — Optional Chaining Missing',
        repository:url,filePath:'src/routes/users.js',lineStart:55,lineEnd:60,codeBlock:'updateUser handler body',
        function:'updateUser',class:null,module:'routes',component:'API Router',astNode:'MemberExpression',
        description:'req.user.id accessed without null check — if authenticate() fails silently, crashes with TypeError.',
        affectedCode:`async function updateUser(req, res) {\n  const userId = req.user.id; // TypeError if req.user is null/undefined\n  const user = await db.find(userId);\n  res.json(user);\n}`,
        suggestedFix:`async function updateUser(req, res) {\n  if (!req.user?.id) return res.status(401).json({ error: 'Unauthorized' });\n  const userId = req.user.id;\n  const user = await db.find(userId);\n  if (!user) return res.status(404).json({ error: 'User not found' });\n  res.json(user);\n}`,
        refactoringGuidance:'Use optional chaining (?.) for all property accesses on potentially null objects. Add guard clauses at function entry.',
        impactOfFix:'Prevents TypeError crashes. Returns proper 401 response. Improves debuggability.',
        explanation:'If middleware sets req.user = null on error, accessing .id throws "Cannot read properties of null", crashing the handler.',
        remediationSteps:'Add null checks or optional chaining. Enable TypeScript strict mode for compile-time null safety.',
        scoringFactors:{securityImpact:4,runtimeFailure:8,maintainability:6,performance:2,complexity:4},
        standardsReference:'CWE-476 NULL Pointer Dereference',
        impactTags:['null-reference','runtime-crash','availability'],correlatedIssues:['CS-004']},

      {id:'CS-007',severity:'HIGH',category:'bug',title:'Unhandled Promise Rejection Crashes Server',
        repository:url,filePath:'src/middleware/auth.js',lineStart:28,lineEnd:33,codeBlock:'authenticate async function',
        function:'authenticate',class:null,module:'middleware',component:'Authentication',astNode:'FunctionDeclaration',
        description:'async middleware without try/catch causes unhandled promise rejections that crash the Node.js process.',
        affectedCode:`async function authenticate(req, res, next) {\n  const token = req.headers.authorization;\n  const payload = jwt.verify(token, config.JWT_SECRET); // throws!\n  req.user = payload; next();\n}`,
        suggestedFix:`async function authenticate(req, res, next) {\n  try {\n    const token = (req.headers.authorization || '').split(' ')[1];\n    if (!token) return res.status(401).json({ error: 'No token' });\n    req.user = jwt.verify(token, config.JWT_SECRET);\n    next();\n  } catch (err) { next(err); }\n}`,
        refactoringGuidance:'Wrap all async middleware in try/catch. Use next(err) to delegate to Express error handler.',
        impactOfFix:'Prevents process crash on invalid tokens. Returns proper 401 response.',
        explanation:'jwt.verify throws on invalid/expired tokens. Without catch, Node.js emits unhandledRejection, killing the process.',
        remediationSteps:'Add try/catch to all async middleware. Use express-async-errors package for automatic wrapping.',
        scoringFactors:{securityImpact:5,runtimeFailure:10,maintainability:6,performance:2,complexity:3},
        standardsReference:'CWE-248 Uncaught Exception',
        impactTags:['unhandled-exception','availability','runtime-crash'],correlatedIssues:['CS-004']},

      {id:'CS-008',severity:'MEDIUM',category:'bug',title:'Improper Resource Handling — Event Listener Memory Leak',
        repository:url,filePath:'src/utils/events.js',lineStart:18,lineEnd:22,codeBlock:'subscribeToEvents function',
        function:'subscribeToEvents',class:'EventBus',module:'utils',component:'Worker Pool',astNode:'CallExpression',
        description:'EventEmitter listeners added on every request and never removed — heap grows without bound.',
        affectedCode:`function subscribeToEvents(emitter, handler) {\n  emitter.on('data', handler);\n  emitter.on('error', handler);\n  // never removed → memory leak\n}`,
        suggestedFix:`function subscribeToEvents(emitter, handler) {\n  emitter.on('data', handler);\n  emitter.on('error', handler);\n  return function cleanup() {\n    emitter.off('data', handler);\n    emitter.off('error', handler);\n  }; // caller MUST call cleanup()\n}`,
        refactoringGuidance:'Always return cleanup functions. Use emitter.once() for single-use listeners. Set emitter.setMaxListeners() appropriately.',
        impactOfFix:'Eliminates memory leak. Node.js will no longer warn about MaxListenersExceededWarning.',
        explanation:'Each call adds two listeners without removal. After ~10 listeners, Node.js emits MaxListeners warning. Eventually OOM.',
        remediationSteps:'Return cleanup function. Call it in request teardown. Use WeakRef for auto-cleanup if needed.',
        scoringFactors:{securityImpact:2,runtimeFailure:7,maintainability:6,performance:6,complexity:4},
        standardsReference:'CWE-401 Missing Release of Memory After Effective Lifetime',
        impactTags:['memory-leak','resource-handling','availability'],correlatedIssues:[]},

      {id:'CS-009',severity:'MEDIUM',category:'bug',title:'Incorrect API Usage — Deprecated req.param() Removed in Express 5',
        repository:url,filePath:'src/routes/users.js',lineStart:33,lineEnd:33,codeBlock:'getUserById handler',
        function:'getUserById',class:null,module:'routes',component:'API Router',astNode:'CallExpression',
        description:'req.param() removed in Express 5 — breaks at runtime on framework upgrade.',
        affectedCode:`const id = req.param('id'); // removed in Express 5`,
        suggestedFix:`const id = req.params.id;   // route param /users/:id\n// or req.query.id       // query string ?id=\n// or req.body.id        // POST body`,
        refactoringGuidance:'Use specific source (params/query/body) — this is more explicit and secure.',
        impactOfFix:'Future-proofs for Express 5. Makes param source explicit.',
        explanation:'req.param() merged all sources (params/query/body) which was ambiguous and a security risk. Removed in v5.',
        remediationSteps:'grep -r "req.param(" to find all occurrences. Replace with specific source.',
        scoringFactors:{securityImpact:3,runtimeFailure:7,maintainability:7,performance:1,complexity:2},
        standardsReference:'Express.js Migration Guide v4→v5, CWE-242',
        impactTags:['deprecated-api','compatibility','runtime'],correlatedIssues:[]},

      // PERFORMANCE — R-093-099
      {id:'CS-010',severity:'HIGH',category:'performance',title:'N+1 Database Queries — Excessive DB Calls',
        repository:url,filePath:'src/routes/api.js',lineStart:102,lineEnd:109,codeBlock:'listUsers for-of loop',
        function:'listUsers',class:null,module:'routes',component:'API Router',astNode:'ForOfStatement',
        description:'Separate DB query per user in list — 100 users = 101 queries, saturating connection pool.',
        affectedCode:`const users = await db.query('SELECT * FROM users LIMIT 100');\nfor (const user of users.rows) {\n  user.posts = await db.query(\n    'SELECT * FROM posts WHERE user_id = $1', [user.id]\n  );\n}`,
        suggestedFix:`const result = await db.query(\`\n  SELECT u.*, COALESCE(json_agg(p.*) FILTER (WHERE p.id IS NOT NULL), '[]') AS posts\n  FROM users u LEFT JOIN posts p ON p.user_id = u.id\n  GROUP BY u.id LIMIT 100\n\`);`,
        refactoringGuidance:'Use SQL JOINs for one-to-many. Use DataLoader for GraphQL. Use eager loading in ORMs.',
        impactOfFix:'Reduces 101 queries to 1. Eliminates connection pool exhaustion under load. Scales to any user count.',
        explanation:'O(n) queries per request causes cascading timeouts. 100 users with 10ms each = 1s per request.',
        remediationSteps:'Rewrite with JOIN and json_agg. Add query analyzer. Set up N+1 detection in development.',
        scoringFactors:{securityImpact:0,runtimeFailure:6,maintainability:5,performance:10,complexity:5},
        standardsReference:'Database Performance Best Practices, CWE-1049',
        impactTags:['n+1','scalability','performance'],correlatedIssues:[]},

      {id:'CS-011',severity:'HIGH',category:'performance',title:'Blocking Operation — fs.readFileSync in Request Handler',
        repository:url,filePath:'src/routes/api.js',lineStart:190,lineEnd:193,codeBlock:'getTemplate function',
        function:'getTemplate',class:null,module:'routes',component:'API Router',astNode:'CallExpression',
        description:'Synchronous file I/O in request handler blocks the Node.js event loop for all concurrent requests.',
        affectedCode:`function getTemplate(name) {\n  return fs.readFileSync(\`./templates/\${name}.html\`, 'utf8');\n}`,
        suggestedFix:`const cache = new Map();\nasync function getTemplate(name) {\n  if (!cache.has(name)) {\n    const html = await fs.promises.readFile(\`./templates/\${name}.html\`, 'utf8');\n    cache.set(name, html);\n  }\n  return cache.get(name);\n}`,
        refactoringGuidance:'Cache templates at startup. Use async I/O everywhere in request path. Consider template compilation.',
        impactOfFix:'Event loop unblocked for concurrent requests. Template load time drops from ms to μs after first request.',
        explanation:'readFileSync blocks the entire V8 event loop. All other requests queue behind a single disk read.',
        remediationSteps:'Replace with fs.promises.readFile. Pre-load templates at server startup. Monitor event loop lag.',
        scoringFactors:{securityImpact:0,runtimeFailure:6,maintainability:5,performance:10,complexity:3},
        standardsReference:'Node.js Event Loop Best Practices, CWE-400',
        impactTags:['blocking','event-loop','performance','runtime'],correlatedIssues:[]},

      {id:'CS-012',severity:'MEDIUM',category:'performance',title:'Inefficient Algorithm — Redundant Nested Loop O(n²)',
        repository:url,filePath:'lib/parser.js',lineStart:145,lineEnd:153,codeBlock:'findDuplicates function body',
        function:'findDuplicates',class:'Parser',module:'parser',component:'Database Layer',astNode:'ForStatement',
        description:'Duplicate detection uses nested loops O(n²) — degrades dramatically with large inputs.',
        affectedCode:`function findDuplicates(items) {\n  const dups = [];\n  for (let i = 0; i < items.length; i++) {\n    for (let j = i+1; j < items.length; j++) {\n      if (items[i] === items[j]) dups.push(items[i]);\n    }\n  }\n  return dups;\n}`,
        suggestedFix:`function findDuplicates(items) {\n  const seen = new Set();\n  const dups = new Set();\n  for (const item of items) {\n    if (seen.has(item)) dups.add(item);\n    else seen.add(item);\n  }\n  return [...dups]; // O(n) time, O(n) space\n}`,
        refactoringGuidance:'Use Set or Map for O(n) duplicate detection. Sort + adjacent compare for O(n log n) with O(1) space.',
        impactOfFix:'1000 items: 499,500 comparisons → 1000. 10,000 items: 50M → 10,000 comparisons.',
        explanation:'O(n²) complexity becomes unusable at scale. 10k items takes ~25ms; 100k items takes ~2.5 seconds.',
        remediationSteps:'Replace nested loops with Set-based approach. Add Big-O comment on all loop-heavy functions.',
        scoringFactors:{securityImpact:0,runtimeFailure:4,maintainability:7,performance:9,complexity:7},
        standardsReference:'Algorithm Design Best Practices, CWE-1176',
        impactTags:['inefficient-algorithm','redundant-loop','scalability'],correlatedIssues:[]},

      // CODE SMELLS — R-085-092
      {id:'CS-015',severity:'MEDIUM',category:'codesmell',title:'Excessive Function Length — 94 Lines, 7 Responsibilities',
        repository:url,filePath:'src/routes/api.js',lineStart:45,lineEnd:139,codeBlock:'processRequest function body',
        function:'processRequest',class:null,module:'routes',component:'API Router',astNode:'FunctionDeclaration',
        description:'94-line function mixes auth, validation, DB, business logic, formatting, logging, response — violates SRP.',
        affectedCode:`async function processRequest(req, res) {\n  // auth check\n  if (!req.headers.authorization) { /* ... */ }\n  // validation\n  const { error } = schema.validate(req.body);\n  // DB query\n  const user = await db.find(/* ... */);\n  // ... 80 more lines of mixed concerns\n}`,
        suggestedFix:`async function processRequest(req, res) {\n  const user = await authenticate(req);\n  const input = await validateInput(req.body);\n  const result = await executeBusinessLogic(user, input);\n  res.json(formatResponse(result));\n}`,
        refactoringGuidance:'Apply Single Responsibility Principle. Target <30 lines per function, cyclomatic complexity <10.',
        impactOfFix:'Reduces test surface. Each extracted function independently testable. Lowers cyclomatic complexity from 18 to <5.',
        explanation:'Functions with multiple responsibilities are the leading cause of regressions during maintenance.',
        remediationSteps:'Extract each logical block to named functions. Add eslint max-lines-per-function rule.',
        scoringFactors:{securityImpact:1,runtimeFailure:3,maintainability:10,performance:2,complexity:9},
        standardsReference:'Clean Code Chapter 3, SOLID Single Responsibility Principle',
        impactTags:['excessive-length','srp','maintainability'],correlatedIssues:[]},

      {id:'CS-016',severity:'MEDIUM',category:'codesmell',title:'Deep Nesting — 6 Levels',
        repository:url,filePath:'lib/parser.js',lineStart:67,lineEnd:92,codeBlock:'parseData conditional blocks',
        function:'parseData',class:'Parser',module:'parser',component:'Database Layer',astNode:'IfStatement',
        description:'Logic nested 6 levels deep with cascading conditionals — extremely high cognitive complexity.',
        affectedCode:`if (data) {\n  if (data.items) {\n    for (const item of data.items) {\n      if (item.active) {\n        if (item.value > 0) {\n          if (item.category) {\n            process(item);\n          }\n        }\n      }\n    }\n  }\n}`,
        suggestedFix:`const items = data?.items ?? [];\nconst eligible = items.filter(i => i.active && i.value > 0 && i.category);\neligible.forEach(process);`,
        refactoringGuidance:'Use guard clauses, early returns, and functional array methods. Target max 3 nesting levels.',
        impactOfFix:'Reduces cognitive complexity from 18 to 3. Makes the intent immediately clear.',
        explanation:'Cyclomatic complexity of 6+ means 6 independent paths — each must be tested. Code review misses bugs here.',
        remediationSteps:'Add eslint max-depth rule (max: 3). Rewrite with guard clauses.',
        scoringFactors:{securityImpact:1,runtimeFailure:2,maintainability:9,performance:3,complexity:10},
        standardsReference:'Clean Code Chapter 17, CWE-1121 Excessive Nesting',
        impactTags:['deep-nesting','cyclomatic-complexity','readability'],correlatedIssues:[]},

      {id:'CS-017',severity:'MEDIUM',category:'codesmell',title:'Duplicate Code — Error Handler Copied 8 Times',
        repository:url,filePath:'src/routes/users.js',lineStart:12,lineEnd:16,codeBlock:'catch block',
        function:'various',class:null,module:'routes',component:'API Router',astNode:'CatchClause',
        description:'Same try/catch error block copy-pasted across 8 route files — DRY violation with diverging implementations.',
        affectedCode:`} catch (err) {\n  console.error(err.message);\n  res.status(500).json({ error: 'Internal server error' });\n}\n// Identical in users.js, api.js, auth.js, posts.js, admin.js, profile.js, settings.js, uploads.js`,
        suggestedFix:`// Shared error middleware in app.js:\napp.use((err, req, res, next) => {\n  logger.error({ err, path: req.path });\n  res.status(err.status || 500).json({\n    error: process.env.NODE_ENV === 'production' ? 'Internal error' : err.message\n  });\n});\n// In routes: just call next(err)`,
        refactoringGuidance:'Extract to Express error middleware. Replace all catch blocks with next(err).',
        impactOfFix:'One place to update error handling. Consistent behavior. Removes ~32 lines of duplicate code.',
        explanation:'Inconsistencies have already crept in — some files log, some do not, some expose error.message in production.',
        remediationSteps:'Create error-handler.js middleware. Register last in app.js. Replace all catch blocks.',
        scoringFactors:{securityImpact:3,runtimeFailure:2,maintainability:9,performance:1,complexity:4},
        standardsReference:'DRY Principle, Clean Code Chapter 2',
        impactTags:['duplicate-code','dry-violation','maintainability'],correlatedIssues:[]},

      {id:'CS-027',severity:'MEDIUM',category:'codesmell',title:'Overly Complex Conditional — Compound Boolean Chain',
        repository:url,filePath:'src/services/order.js',lineStart:34,lineEnd:38,codeBlock:'canProcessOrder if statement',
        function:'canProcessOrder',class:'OrderService',module:'services',component:'API Router',astNode:'LogicalExpression',
        description:'Single if statement with 7 boolean conditions makes logic impossible to understand or test individually.',
        affectedCode:`if (user.active && user.verified && user.creditScore > 600 &&\n    order.total < 10000 && order.items.length > 0 &&\n    !user.suspended && Date.now() < order.expiresAt) {\n  processOrder(order);\n}`,
        suggestedFix:`const isUserEligible = user.active && user.verified && !user.suspended && user.creditScore > 600;\nconst isOrderValid = order.items.length > 0 && order.total < 10000 && Date.now() < order.expiresAt;\nif (isUserEligible && isOrderValid) {\n  processOrder(order);\n}`,
        refactoringGuidance:'Extract boolean groups into named variables. Each variable tests one concern and self-documents.',
        impactOfFix:'Logic readable at a glance. Each condition independently testable. Easier to extend.',
        explanation:'7-condition boolean chains have 128 possible input combinations — comprehensive testing is impractical.',
        remediationSteps:'Break into named boolean variables. Add eslint complexity rule. Consider a specification pattern.',
        scoringFactors:{securityImpact:1,runtimeFailure:3,maintainability:8,performance:1,complexity:9},
        standardsReference:'Clean Code Chapter 4, Refactoring by Martin Fowler — Decompose Conditional',
        impactTags:['complex-conditional','readability','testability'],correlatedIssues:[]},

      // ARCHITECTURE — R-023
      {id:'CS-025',severity:'MEDIUM',category:'architecture',title:'Circular Dependency: config ↔ database modules',
        repository:url,filePath:'src/utils/db.js',lineStart:1,lineEnd:3,codeBlock:'require statement at module top',
        function:'module-init',class:null,module:'database',component:'Database Layer',astNode:'CallExpression',
        description:'config.js imports db.js for config stored in DB; db.js imports config.js for connection — circular.',
        affectedCode:`const config = require('../config'); // config.js imports THIS file!\nconst pool = new Pool(config.dbConfig);`,
        suggestedFix:`// Use dependency injection:\nfunction createPool(dbConfig) {\n  return new Pool(dbConfig);\n}\nmodule.exports = { createPool };\n// In app.js: const pool = createPool(process.env.DATABASE_URL);`,
        refactoringGuidance:'Use dependency injection. Pass config as constructor parameter. Avoid module-level side effects.',
        impactOfFix:'Eliminates circular dependency. Enables mocking DB in tests. Predictable init order.',
        explanation:'Circular imports cause modules to receive incomplete objects (undefined properties) depending on load order.',
        remediationSteps:'Run madge --circular to detect all circular deps. Use DI pattern. Refactor in small steps.',
        scoringFactors:{securityImpact:2,runtimeFailure:6,maintainability:9,performance:2,complexity:7},
        standardsReference:'SOLID Dependency Inversion Principle, CWE-1047',
        impactTags:['circular-dependency','architecture','init-order'],correlatedIssues:[]},

      {id:'CS-026',severity:'LOW',category:'architecture',title:'No API Versioning — Breaking Changes Undeployable Safely',
        repository:url,filePath:'src/routes/api.js',lineStart:1,lineEnd:6,codeBlock:'router route registrations',
        function:'module',class:null,module:'routes',component:'API Router',astNode:'StringLiteral',
        description:'All routes at /api/* with no versioning — any breaking change forces all clients to update simultaneously.',
        affectedCode:`router.get('/users', listUsers);\nrouter.post('/users', createUser);\n// No versioning: /api/users`,
        suggestedFix:`const v1 = express.Router();\nv1.get('/users', listUsers);\nv1.post('/users', createUser);\napp.use('/api/v1', v1);\n// Future: app.use('/api/v2', v2);`,
        refactoringGuidance:'Version from day one. Use URL path versioning (/v1/) as the most explicit approach.',
        impactOfFix:'Enables safe breaking changes. Clients can migrate at their own pace.',
        explanation:'Without versioning, any schema change is a breaking change requiring simultaneous client+server deploy.',
        remediationSteps:'Prefix all routes with /v1. Add API changelog. Set deprecation headers on old versions.',
        scoringFactors:{securityImpact:1,runtimeFailure:3,maintainability:8,performance:1,complexity:4},
        standardsReference:'RESTful API Design Best Practices, API Versioning Strategy',
        impactTags:['api-versioning','backwards-compat','architecture'],correlatedIssues:[]},

      // CONCURRENCY — R-071
      {id:'CS-019',severity:'HIGH',category:'concurrency',title:'Race Condition — Shared Mutable Cache Without Lock',
        repository:url,filePath:'src/workers/processor.js',lineStart:34,lineEnd:42,codeBlock:'processJob read-modify-write',
        function:'processJob',class:'JobProcessor',module:'workers',component:'Worker Pool',astNode:'AssignmentExpression',
        description:'Multiple async worker invocations read-modify-write shared object without lock — lost update race condition.',
        affectedCode:`const sharedCache = {}; // shared across all invocations\nasync function processJob(jobId) {\n  const count = sharedCache[jobId] || 0;\n  await doWork(); // ← other invocations can modify here\n  sharedCache[jobId] = count + 1; // stale read → lost update\n}`,
        suggestedFix:`const { Mutex } = require('async-mutex');\nconst mutex = new Mutex();\nasync function processJob(jobId) {\n  const release = await mutex.acquire();\n  try {\n    const count = sharedCache[jobId] || 0;\n    sharedCache[jobId] = count + 1;\n  } finally { release(); }\n  await doWork();\n}`,
        refactoringGuidance:'Use async-mutex for in-process sync. Use Redis INCR for distributed scenarios.',
        impactOfFix:'Eliminates lost updates under concurrent load. Counter always accurate.',
        explanation:'async/await yields at await points — another invocation runs between read and write, both seeing old value.',
        remediationSteps:'Install async-mutex. Identify all shared mutable state. Apply lock-then-modify pattern.',
        scoringFactors:{securityImpact:3,runtimeFailure:8,maintainability:6,performance:4,complexity:7},
        standardsReference:'CWE-362 Race Condition, Node.js Concurrency Patterns',
        impactTags:['race-condition','concurrency','data-corruption'],correlatedIssues:['CS-020','COR-004']},

      {id:'CS-020',severity:'HIGH',category:'concurrency',title:'Missing Transaction — Concurrent Writes Risk Partial Updates',
        repository:url,filePath:'src/workers/processor.js',lineStart:67,lineEnd:74,codeBlock:'batchUpdate Promise.all',
        function:'batchUpdate',class:'JobProcessor',module:'workers',component:'Worker Pool',astNode:'AwaitExpression',
        description:'Promise.all with concurrent DB writes — no transaction isolation means partial failure leaves inconsistent state.',
        affectedCode:`async function batchUpdate(userIds, updates) {\n  await Promise.all(userIds.map(id =>\n    db.query('UPDATE users SET status=$1 WHERE id=$2', [updates.status, id])\n  ));\n}`,
        suggestedFix:`async function batchUpdate(userIds, updates) {\n  const client = await pool.connect();\n  try {\n    await client.query('BEGIN');\n    for (const id of userIds) {\n      await client.query('UPDATE users SET status=$1 WHERE id=$2', [updates.status, id]);\n    }\n    await client.query('COMMIT');\n  } catch (err) { await client.query('ROLLBACK'); throw err; }\n  finally { client.release(); }\n}`,
        refactoringGuidance:'Always use transactions for multi-row mutations. Use BEGIN/COMMIT/ROLLBACK explicitly.',
        impactOfFix:'Atomic operation — either all succeed or all rolled back. No partial state possible.',
        explanation:'If one update fails, previous updates already committed. DB is in partially-updated inconsistent state.',
        remediationSteps:'Wrap batch mutations in transactions. Use pg-promise for ergonomic transaction API.',
        scoringFactors:{securityImpact:3,runtimeFailure:9,maintainability:6,performance:3,complexity:6},
        standardsReference:'CWE-667 Improper Locking, Database ACID Properties',
        impactTags:['transaction','concurrency','data-integrity'],correlatedIssues:['CS-019','COR-004']},

      {id:'CS-021',severity:'MEDIUM',category:'concurrency',title:'Double-Initialization Race on Singleton',
        repository:url,filePath:'src/utils/db.js',lineStart:5,lineEnd:12,codeBlock:'getPool lazy init',
        function:'getPool',class:'DatabaseSingleton',module:'database',component:'Database Layer',astNode:'IfStatement',
        description:'Lazy pool initialization without promise guard allows multiple concurrent callers to create duplicate pools.',
        affectedCode:`let pool = null;\nasync function getPool() {\n  if (!pool) { // two callers both pass this check\n    pool = new Pool(config.db);\n    await pool.connect(); // both create a pool!\n  }\n  return pool;\n}`,
        suggestedFix:`let pool = null;\nlet initPromise = null;\nasync function getPool() {\n  if (!initPromise) {\n    initPromise = (async () => { pool = new Pool(config.db); await pool.connect(); })();\n  }\n  await initPromise; return pool;\n}`,
        refactoringGuidance:'Use a shared init promise as a synchronization primitive. Any caller awaits the same promise.',
        impactOfFix:'Exactly one pool created regardless of concurrency. Eliminates connection leak on startup.',
        explanation:'Between the if (!pool) check and pool = new Pool(), another async call can enter the same branch.',
        remediationSteps:'Apply promise-based singleton pattern. Consider using a DI container to manage lifecycle.',
        scoringFactors:{securityImpact:2,runtimeFailure:7,maintainability:6,performance:5,complexity:6},
        standardsReference:'CWE-362 Race Condition, Singleton Pattern',
        impactTags:['race-condition','singleton','resource-leak'],correlatedIssues:[]},

      // DEAD CODE — R-072
      {id:'CS-022',severity:'LOW',category:'deadcode',title:'Unreachable Code After Return Statement',
        repository:url,filePath:'src/routes/users.js',lineStart:45,lineEnd:53,codeBlock:'updateUser early return block',
        function:'updateUser',class:null,module:'routes',component:'API Router',astNode:'ReturnStatement',
        description:'Logging and metrics calls placed after return statement — never executed in any code path.',
        affectedCode:`if (!req.user) {\n  return res.status(401).json({ error: 'Unauthorized' });\n  logger.info('Auth failure');   // UNREACHABLE\n  metrics.increment('auth.fail'); // UNREACHABLE\n}`,
        suggestedFix:`if (!req.user) {\n  logger.info('Auth failure');    // moved before return\n  metrics.increment('auth.fail');\n  return res.status(401).json({ error: 'Unauthorized' });\n}`,
        refactoringGuidance:'Move all side effects (logging, metrics) before return. Enable eslint no-unreachable rule.',
        impactOfFix:'Restores observability — auth failures now correctly logged and metered.',
        explanation:'Code after a return is syntactically valid but semantically dead — the intent was observability but it never runs.',
        remediationSteps:'Enable eslint no-unreachable. Run static analysis to detect all such patterns.',
        scoringFactors:{securityImpact:2,runtimeFailure:4,maintainability:7,performance:1,complexity:3},
        standardsReference:'CWE-561 Dead Code',
        impactTags:['dead-code','observability','unreachable'],correlatedIssues:[]},

      {id:'CS-023',severity:'LOW',category:'deadcode',title:'23 Unused Exports Detected by AST Analysis',
        repository:url,filePath:'src/utils/legacy.js',lineStart:1,lineEnd:120,codeBlock:'export declarations',
        function:'various',class:'LegacyUtils',module:'utils',component:'Database Layer',astNode:'ExportNamedDeclaration',
        description:'AST cross-reference found 23 exports in legacy.js never imported anywhere in the codebase.',
        affectedCode:`// legacy.js — never imported anywhere:\nexport function parseOldFormat(data) { /* ... */ }\nexport function convertV1Schema(schema) { /* ... */ }\nexport function migrateUserData(user) { /* ... */ }\n// ...20 more unused exports`,
        suggestedFix:`// Run: npx ts-prune to verify\n// Then delete or internalize:\n// Option A: Delete legacy.js entirely\n// Option B: Mark internal (remove 'export' keyword)\n// Option C: Move to __tests__ if needed for testing only`,
        refactoringGuidance:'Run ts-prune or eslint-plugin-unused-imports in CI. Treat unused exports as compilation errors.',
        impactOfFix:'Reduces bundle size. Clarifies API surface. Removes code that may contain unpatched vulnerabilities.',
        explanation:'Unused exports expand the attack surface — vulnerabilities in dead code still need patching.',
        remediationSteps:'Add ts-prune to CI pipeline. Delete confirmed-unused exports. Document intentional unused APIs.',
        scoringFactors:{securityImpact:2,runtimeFailure:1,maintainability:7,performance:3,complexity:3},
        standardsReference:'CWE-561 Dead Code',
        impactTags:['dead-code','bundle-size','maintainability'],correlatedIssues:[]},

      {id:'CS-024',severity:'INFO',category:'deadcode',title:'Feature Flag Hardcoded False — Code Branch Never Runs',
        repository:url,filePath:'src/services/payment.js',lineStart:8,lineEnd:14,codeBlock:'USE_NEW_PAYMENT_FLOW if block',
        function:'processPayment',class:'PaymentService',module:'services',component:'API Router',astNode:'IfStatement',
        description:'const USE_NEW_PAYMENT_FLOW = false hardcoded — new payment path is dead code in all environments.',
        affectedCode:`const USE_NEW_PAYMENT_FLOW = false; // TODO: enable\nasync function processPayment(order) {\n  if (USE_NEW_PAYMENT_FLOW) {\n    return newPaymentFlow(order); // NEVER RUNS\n  }\n  return legacyPaymentFlow(order);\n}`,
        suggestedFix:`const USE_NEW_PAYMENT_FLOW = process.env.FEATURE_NEW_PAYMENT === 'true';\nasync function processPayment(order) {\n  return USE_NEW_PAYMENT_FLOW ? newPaymentFlow(order) : legacyPaymentFlow(order);\n}`,
        refactoringGuidance:'Use environment-variable feature flags. Remove hardcoded booleans. Use a feature flag service in production.',
        impactOfFix:'New payment path testable in staging. Enables gradual rollout without code changes.',
        explanation:'Hardcoded false means the new code path accumulates bugs that are invisible until the flag is enabled.',
        remediationSteps:'Replace with env var flag. Set up LaunchDarkly or Unleash for sophisticated rollouts.',
        scoringFactors:{securityImpact:1,runtimeFailure:2,maintainability:6,performance:1,complexity:3},
        standardsReference:'Feature Flag Best Practices, CWE-561',
        impactTags:['dead-code','feature-flag','maintainability'],correlatedIssues:[]},

      // NAMING — R-089
      {id:'CS-018',severity:'LOW',category:'naming',title:'Misleading Name + Single-Letter Variables',
        repository:url,filePath:'src/services/user.js',lineStart:22,lineEnd:30,codeBlock:'getUser function body',
        function:'getUser',class:'UserService',module:'services',component:'Authentication',astNode:'FunctionDeclaration',
        description:'getUser actually deletes the user. Variables d, u, r used throughout — intent completely opaque.',
        affectedCode:`async function getUser(d) { // d = userId? date? data?\n  const u = await db.find(d);\n  const r = await db.delete(u.id); // BUG: this DELETES!\n  return r;\n}`,
        suggestedFix:`async function deleteUserById(userId) {\n  const user = await db.find(userId);\n  if (!user) throw new NotFoundError(\`User \${userId} not found\`);\n  const result = await db.delete(user.id);\n  return result;\n}`,
        refactoringGuidance:'Name functions verb+noun+context. Minimum 3-character variable names outside loop indices.',
        impactOfFix:'Intent immediately clear. Prevents callers from accidentally deleting instead of reading.',
        explanation:'getUser violates the principle of least surprise — any caller expecting a read operation causes a delete.',
        remediationSteps:'Rename immediately. Add eslint id-length (min: 3) and explicit-function-return-type rules.',
        scoringFactors:{securityImpact:4,runtimeFailure:6,maintainability:9,performance:1,complexity:5},
        standardsReference:'Clean Code Chapter 2 — Meaningful Names, CWE-1164',
        impactTags:['naming','misleading-function','readability'],correlatedIssues:[]},
    ]
  };
}

