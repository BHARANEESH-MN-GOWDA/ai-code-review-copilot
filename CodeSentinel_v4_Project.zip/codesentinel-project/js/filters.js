/* FILTERS */
function fSev(s){F.sev=F.sev===s?null:s;renderIssues(DATA.findings);}
function fCat(c){F.cat=F.cat===c?null:c;renderIssues(DATA.findings);}
function filterFile(f){F.file=f;renderIssues(DATA.findings);}
function fComp(c){F.comp=F.comp===c?null:c;renderIssues(DATA.findings);stab('filter');}
function clrF(){F={sev:null,cat:null,file:null,comp:null};renderIssues(DATA.findings);}

/* SIDEBAR TABS */
function stab(t){
  ['files','filter','comp','arch'].forEach(s=>{
    document.getElementById(`st-${s}`).classList.toggle('on',s===t);
    document.getElementById(`sb-${s}`).classList.toggle('hidden',s!==t);
  });
}

/* PANELS */
function togPanel(bodyId,chevId){
  const b=document.getElementById(bodyId);b.classList.toggle('open');
  const ch=document.getElementById(chevId);if(ch)ch.classList.toggle('open',b.classList.contains('open'));
}
function togCard(id){document.getElementById(`ic-${id}`)?.classList.toggle('open');}

