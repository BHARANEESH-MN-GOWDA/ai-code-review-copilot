window.addEventListener('DOMContentLoaded',()=>{
  renderArch({architecture:{diagram:defArch()}});
